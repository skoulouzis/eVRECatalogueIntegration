var token;
function getToken() {
    console.log('----------------');
    var psw = document.getElementById("psw").value;
    var uname = document.getElementById("uname").value;
    
    var nodeService = 'http://v4e-lab.isti.cnr.it:8080/NodeService/user/login?pwd=' + psw + '&username=' + uname;
    var request = new XMLHttpRequest();
    request.open('GET', nodeService, false);
    request.send(null);
    if (request.status === 200) {
        var json = JSON.parse(request.responseText);
        console.log(json);
        if (json.status ==='SUCCEED'){
            token = json.token;
            console.log(token);
            alert("login successful");
        }
    }
    
}


